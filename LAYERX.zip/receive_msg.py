#!/usr/bin/env python3
"""
LayerX Secure Messenger - RECEIVER
Automatic peer discovery + encrypted message reception with steganography
"""

import os
import json
import base64
import socket
import struct
import threading
import time
import numpy as np
import cv2
from nacl.public import PrivateKey, PublicKey, Box
from nacl.signing import VerifyKey, SigningKey

# Import LayerX steganography modules
from a3_image_processing import dwt_decompose
from a5_embedding_extraction import extract_from_dwt_bands

# Configuration
BROADCAST_PORT = 65432
CHAT_PORT = 9000
BROADCAST_INTERVAL = 5
MY_IDENTITY_FILE = 'my_identity.json'
PEERS_FILE = 'peers.json'

def get_local_ip():
    """Get local IP address"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip

def generate_keys(username):
    """Generate keys for new user"""
    signing_key = SigningKey.generate()
    encryption_key = PrivateKey.generate()
    
    return {
        "username": username,
        "ip": get_local_ip(),
        "signing_private": base64.b64encode(bytes(signing_key)).decode(),
        "signing_public": base64.b64encode(bytes(signing_key.verify_key)).decode(),
        "x25519_private": base64.b64encode(bytes(encryption_key)).decode(),
        "x25519_public": base64.b64encode(bytes(encryption_key.public_key)).decode()
    }

def load_or_create_identity():
    """Load or create identity"""
    if os.path.exists(MY_IDENTITY_FILE):
        with open(MY_IDENTITY_FILE) as f:
            identity = json.load(f)
        identity["ip"] = get_local_ip()
        with open(MY_IDENTITY_FILE, "w") as f:
            json.dump(identity, f, indent=2)
        print(f"✓ Loaded identity: {identity['username']} ({identity['ip']})")
        return identity
    
    username = input("Enter your username: ").strip()
    identity = generate_keys(username)
    with open(MY_IDENTITY_FILE, "w") as f:
        json.dump(identity, f, indent=2)
    print(f"✓ Created identity: {username}")
    return identity

def load_peers():
    """Load peers list"""
    if os.path.exists(PEERS_FILE):
        with open(PEERS_FILE) as f:
            return json.load(f)
    return []

def save_peers(peers):
    """Save peers list"""
    with open(PEERS_FILE, "w") as f:
        json.dump(peers, f, indent=2)

def broadcast_identity(my_identity, stop_event):
    """Broadcast presence to network"""
    ip_prefix = '.'.join(my_identity['ip'].split('.')[:3])
    broadcast_ip = f"{ip_prefix}.255"
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    
    payload = {
        "username": my_identity["username"],
        "ip": my_identity["ip"],
        "signing_public": my_identity["signing_public"],
        "x25519_public": my_identity["x25519_public"]
    }
    
    message = json.dumps(payload).encode()
    
    while not stop_event.is_set():
        try:
            sock.sendto(message, (broadcast_ip, BROADCAST_PORT))
        except:
            pass
        stop_event.wait(BROADCAST_INTERVAL)
    
    sock.close()

def listen_for_peers(my_identity, peers_list, stop_event):
    """Listen for peer broadcasts"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(('', BROADCAST_PORT))
    sock.settimeout(1.0)
    
    while not stop_event.is_set():
        try:
            data, addr = sock.recvfrom(2048)
            peer = json.loads(data.decode())
            
            # Skip self
            if peer["username"] == my_identity["username"]:
                continue
            
            # Add or update peer
            existing = next((p for p in peers_list if p["username"] == peer["username"]), None)
            if not existing:
                peers_list.append(peer)
                save_peers(peers_list)
                print(f"\n🆕 Discovered: {peer['username']} ({peer['ip']})")
            elif existing["ip"] != peer["ip"]:
                existing.update(peer)
                save_peers(peers_list)
                
        except socket.timeout:
            continue
        except:
            pass
    
    sock.close()

def get_peer_by_ip(ip, peers_list):
    """Find peer by IP address"""
    return next((p for p in peers_list if p["ip"] == ip), None)

def receive_stego_image():
    """Receive stego image via TCP"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(('', CHAT_PORT))
    sock.listen(1)
    
    conn, addr = sock.accept()
    
    # Receive length
    length_data = conn.recv(4)
    length = struct.unpack('>I', length_data)[0]
    
    # Receive image data
    data = b""
    while len(data) < length:
        chunk = conn.recv(min(4096, length - len(data)))
        if not chunk:
            break
        data += chunk
    
    conn.close()
    sock.close()
    
    # Decode image
    nparr = np.frombuffer(data, np.uint8)
    stego_image = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)
    
    return stego_image, addr[0]

def extract_and_decrypt(stego_image, sender_ip, my_identity, peers_list):
    """Extract and decrypt message from stego image"""
    # Decompose image
    bands = dwt_decompose(stego_image)
    
    # Try different payload sizes
    for size_bytes in [200, 500, 1000, 2000, 5000]:
        try:
            payload_bits = extract_from_dwt_bands(bands, size_bytes * 8)
            payload_bytes = bytes(int(payload_bits[i:i+8], 2) for i in range(0, len(payload_bits), 8))
            
            # Try to parse JSON
            data = json.loads(payload_bytes.decode('utf-8'))
            sender_username = data["sender"]
            signed_data = base64.b64decode(data["signed_data"])
            
            # Find sender peer
            peer = get_peer_by_ip(sender_ip, peers_list)
            if not peer:
                print(f"⚠️ Unknown sender: {sender_ip}")
                return None
            
            # Verify signature
            verify_key = VerifyKey(base64.b64decode(peer["signing_public"]))
            verified_data = verify_key.verify(signed_data)
            
            # Decrypt
            my_priv = PrivateKey(base64.b64decode(my_identity["x25519_private"]))
            peer_pub = PublicKey(base64.b64decode(peer["x25519_public"]))
            box = Box(my_priv, peer_pub)
            message = box.decrypt(verified_data).decode('utf-8')
            
            return sender_username, message
            
        except:
            continue
    
    return None

def receive_loop(my_identity, peers_list, stop_event):
    """Main receive loop"""
    print(f"📡 Listening on port {CHAT_PORT}...\n")
    
    while not stop_event.is_set():
        try:
            print("⏳ Waiting for message...")
            stego_image, sender_ip = receive_stego_image()
            
            print(f"📩 Received from {sender_ip}")
            print("🔓 Extracting and decrypting... ", end='', flush=True)
            
            result = extract_and_decrypt(stego_image, sender_ip, my_identity, peers_list)
            
            if result:
                sender, message = result
                print("✓\n")
                print("="*70)
                print(f"💬 From: {sender} ({sender_ip})")
                print(f"📝 Message: {message}")
                print("="*70 + "\n")
            else:
                print("❌ Failed to decrypt\n")
        
        except KeyboardInterrupt:
            stop_event.set()
            break
        except Exception as e:
            print(f"❌ Error: {e}\n")
            continue

def main():
    """Main receiver"""
    print("="*70)
    print("LAYERX SECURE MESSENGER - RECEIVER")
    print("="*70)
    
    my_identity = load_or_create_identity()
    peers_list = load_peers()
    stop_event = threading.Event()
    
    # Start broadcast thread
    threading.Thread(target=broadcast_identity, args=(my_identity, stop_event), daemon=True).start()
    
    # Start listener thread
    threading.Thread(target=listen_for_peers, args=(my_identity, peers_list, stop_event), daemon=True).start()
    
    print(f"\n📡 Discovering peers...\n")
    time.sleep(2)
    
    try:
        receive_loop(my_identity, peers_list, stop_event)
    except KeyboardInterrupt:
        stop_event.set()
        print("\n👋 Interrupted")

if __name__ == "__main__":
    main()
